package az.atlacademy.springjdbctemplateexample.dao;

import az.atlacademy.springjdbctemplateexample.model.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Optional;

@Repository
public class StudentJdbcTemplateDao implements StudentDao<Student> {

    private static final String FIND_STUDENT_BY_ID = "SELECT * FROM students WHERE id = ?;";
    private JdbcTemplate jdbcTemplate;

    //@Autowired
    public StudentJdbcTemplateDao(DataSource dataSource) {
        this.jdbcTemplate = new JdbcTemplate(dataSource);
    }

    @Override
    public Optional<Student> findById(Long id) {
        return Optional.of(jdbcTemplate.queryForObject(FIND_STUDENT_BY_ID, new Object[]{id}, new RowMapper<Student>() {
            @Override
            public Student mapRow(ResultSet rs, int rowNum) throws SQLException {
                Student student = new Student();
                student.setId(rs.getLong("id"));
                student.setName(rs.getString("name"));
                student.setSurname(rs.getString("surname"));
                student.setAge(rs.getInt("age"));
                return student;
            }
        }));
    }

}
