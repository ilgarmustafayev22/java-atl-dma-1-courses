package az.atlacademy.springjdbctemplateexample.controller;

public class StudentController {

    private final StudentService studentService;

    public StudentController(StudentService studentService) {
        this.studentService = studentService;
    }

    public Student findByName(String name) {
        if (name == null || name.isEmpty()) {
            throw new IllegalArgumentException();
        }
        return studentService.findByName(name);
    }

}
