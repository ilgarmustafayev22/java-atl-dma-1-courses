package az.atlacademy.springjdbctemplateexample.dao;

import java.util.Optional;

public interface StudentDao<E>{

    Optional<E> findById(Long id);

}
