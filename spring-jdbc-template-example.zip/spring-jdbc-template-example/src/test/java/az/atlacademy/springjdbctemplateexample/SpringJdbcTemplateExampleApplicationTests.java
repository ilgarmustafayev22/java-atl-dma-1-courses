package az.atlacademy.springjdbctemplateexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringJdbcTemplateExampleApplicationTests {

    @Test
    void contextLoads() {
    }

}
